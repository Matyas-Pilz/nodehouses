Node houses is a mod by MatyasP that adds one-node block of houses, for crafting using items from mode default.
