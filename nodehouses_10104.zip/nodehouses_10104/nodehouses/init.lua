-- Inicializace modu
nodehouses = {}

-- Na�ten� dal��ch soubor�
dofile(minetest.get_modpath("nodehouses").."/houses.lua")
dofile(minetest.get_modpath("nodehouses").."/crafting.lua")
dofile(minetest.get_modpath("nodehouses").."/buildparts.lua")

