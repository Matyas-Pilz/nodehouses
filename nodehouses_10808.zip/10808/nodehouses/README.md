Node houses is a mod by MatyasP that adds one-node block of houses, 
craftable by using items from mode default.

Knowed issues: repainting doing only different work that is needed.


